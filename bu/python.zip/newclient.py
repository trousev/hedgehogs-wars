#!/usr/bin/python3

import sys
import cmd
from pprint import pprint

import comm

# Parse options

clientconf = dict()
stringparams = ('address', 'name')

for opt in sys.argv[1:]:
    if opt.startswith('-C'):
        conf = clientconf
    else:
        raise ArgumentError("unrecognized command line option")

    name, value = opt[2:].split('=', 1)
    name = name.strip().lower().replace('-', '_')
    conf[name] = int(value.strip()) if name not in stringparams else value

# Begin communication
print (value)
me = comm.Client(value)

i = 0
for (board, myself) in me.connect():
    print (board)
    print ("next")
    print (myself)
    if i == 0:
        me.throw_cabbage (2,-1)
        
        
    elif i == 1:
        me.relax()
               
    
    i = ( i + 1 ) % 2
    


